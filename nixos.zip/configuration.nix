# Edit this configuration file to define what should be installed on
# your system. Help is available in the configuration.nix(5) man page, on
# https://search.nixos.org/options and in the NixOS manual (`nixos-help`).

{ config, pkgs, ... }:

{
  imports = [
    ./hardware-configuration.nix
  ];

  # Enable Flakes and modern Nix CLI
  nix.settings.experimental-features = [ "nix-command" "flakes" ];

  # Bootloader
  boot.loader.systemd-boot.enable = true;
  boot.loader.efi.canTouchEfiVariables = true;
  boot.kernelParams = [ "nvidia-drm.fbdev=1" ];

  # Networking
  networking.hostName = "nixos";
  networking.networkmanager.enable = true;

  # Localization & Timezone
  time.timeZone = "Asia/Bangkok";
  i18n.defaultLocale = "en_US.UTF-8";
  i18n.extraLocaleSettings = {
    LC_ADDRESS = "en_US.UTF-8";
    LC_IDENTIFICATION = "en_US.UTF-8";
    LC_MEASUREMENT = "en_US.UTF-8";
    LC_MONETARY = "en_US.UTF-8";
    LC_NAME = "en_US.UTF-8";
    LC_NUMERIC = "en_US.UTF-8";
    LC_PAPER = "en_US.UTF-8";
    LC_TELEPHONE = "en_US.UTF-8";
    LC_TIME = "en_US.UTF-8";
  };

  # Display & Graphics (NVIDIA + Wayland)
  hardware.graphics = {
    enable = true;
    enable32Bit = true;
  };

  services.xserver.videoDrivers = [ "nvidia" ];

  security.sudo = {
    enable = true;
    extraConfig = ''
      # Keep Wayland environment variables when switching to root
      Defaults env_keep += "XDG_RUNTIME_DIR WAYLAND_DISPLAY DISPLAY"
    '';
  };

  hardware.nvidia = {
    modesetting.enable = true;
    powerManagement.enable = true;
    open = false;
    nvidiaSettings = true;
    package = config.boot.kernelPackages.nvidiaPackages.stable;
  };

  # Environment Variables for NVIDIA + Wayland + Electron Apps
  environment.sessionVariables = {
    LIBVA_DRIVER_NAME = "nvidia";
    XDG_SESSION_TYPE = "wayland";
    GBM_BACKEND = "nvidia-drm";
    __GLX_VENDOR_LIBRARY_NAME = "nvidia";
    NVD_BACKEND = "direct";
    NIXOS_OZONE_WL = "1";
    ELECTRON_OZONE_PLATFORM_HINT = "auto";
  };

  # MangoWC Compositor & Portal
  programs.mango.enable = true;
  programs.xwayland.enable = true;

  xdg.portal = {
    enable = true;
    wlr.enable = true;
    extraPortals = [
      pkgs.xdg-desktop-portal-wlr
      pkgs.xdg-desktop-portal-gtk
    ];
  };

  # Polkit & Device Management
  security.polkit.enable = true;
  services.gvfs.enable = true; # Trash, SMB, MTP support
  services.tumbler.enable = true; # Thumbnail generator
  services.udisks2.enable = true; # Auto-mount removable media

    # Display Manager (Ly, a TUI login manager)
  services.displayManager.ly.enable = true;
  services.displayManager.defaultSession = "mango";
  # Keyboard Layout (Fallback for X11/Display Manager)
  services.xserver.xkb = {
    layout = "us,th";
    variant = "";
  };

  # Printing & Scanning Services
  services.printing = {
    enable = true;
    drivers = with pkgs; [
      epson-escpr
    ];
  };

  # Scanner Support (SANE)
  hardware.sane = {
    enable = true;
    extraBackends = [ pkgs.sane-airscan ];
  };

  services.avahi = {
    enable = true;
    nssmdns4 = true;
    openFirewall = true;
  };

  # Audio
  services.pulseaudio.enable = false;
  security.rtkit.enable = true;
  services.pipewire = {
    enable = true;
    alsa.enable = true;
    alsa.support32Bit = true;
    pulse.enable = true;
  };

  # Dynamic binary execution support
  programs.nix-ld.enable = true;

  # User Accounts
  users.users.kamil = {
    isNormalUser = true;
    description = "Kamil Bn";
    extraGroups = [ "networkmanager" "wheel" "scanner" "lp" "video" "input" ];
    packages = with pkgs; [];
  };

  # Programs & Gaming
  programs.firefox.enable = true;
  programs.steam = {
    enable = true;
    remotePlay.openFirewall = true;
    dedicatedServer.openFirewall = true;
  };

  services.flatpak.enable = true;

  programs.gamemode.enable = true;

  nixpkgs.config.allowUnfree = true;

  # System Packages
  environment.systemPackages = with pkgs; [
    # --- Desktop Environment Core Utilities ---
    hyprpolkitagent      # Polkit graphical authentication agent
    libnotify            # Notification popups (notify-send)
    rofi                 # Application launcher & runner
    swaybg
    grim                 # Screenshot utility
    slurp                # Region selection tool
    wl-clipboard         # Clipboard integration
    brightnessctl        # Brightness management
    pavucontrol          # Graphical Audio Control
    waybar
    mako
    imagemagick

    # --- Essential DE Desktop Applications ---
    nemo-with-extensions # File Manager
    adwaita-icon-theme
    file-roller          # Archive Manager
    loupe                # Image Viewer
    celluloid            # Video Player
    evince               # Document Reader
    gnome-calculator     # Calculator
    system-config-printer# Printer Manager GUI
    simple-scan          # Scanner GUI

    # Archive / Compression Backend Engines
    p7zip
    unrar
    unzip
    zip
    gnutar
    gzip

    # --- Terminal & Dev Tools ---
    alacritty
    xclip
    xsel
    neovim
    wget
    curl
    git
    fastfetch
    btop
    stdenv
    gcc
    gnumake
    fd
    ripgrep
    tree
    sassc
    tree-sitter
    nodejs

    # --- Language Servers (LSPs) & Formatters ---
    lua-language-server
    pyright
    bash-language-server
    stylua
    black
    isort
    prettierd

    # --- Productivity & Media ---
    obsidian
    libreoffice
    blender
    mpv
    zathura
    motrix

    # --- Gaming ---
    prismlauncher
    mangohud
    heroic
  ];

  # Fonts Configuration
  fonts = {
    enableDefaultPackages = true;
    fontconfig.enable = true;

    packages = with pkgs; [
      google-fonts
      noto-fonts
      noto-fonts-color-emoji
      noto-fonts-cjk-sans
      tlwg
      ibm-plex
      sarabun-font
      unifont

      # Nerd Fonts
      nerd-fonts.fira-code
      nerd-fonts.jetbrains-mono
      nerd-fonts.iosevka
      nerd-fonts.iosevka-term
      nerd-fonts.caskaydia-cove
      nerd-fonts.bigblue-terminal
      nerd-fonts.gohufont
    ];

    fontconfig.defaultFonts = {
      serif = [ "Noto Serif" "Noto Serif Thai" "Garuda" ];
      sansSerif = [ "IBM Plex Sans" "IBM Plex Sans Thai" "Noto Sans Thai" "Sarabun" ];
      monospace = [ "JetBrainsMono Nerd Font" "Iosevka Nerd Font" "Loma" "TlwgMono" ];
      emoji = [ "Noto Color Emoji" ];
    };
  };

  system.stateVersion = "26.05";
}
