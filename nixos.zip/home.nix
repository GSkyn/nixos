{ pkgs, inputs, ... }:

let
  spicePkgs = inputs.spicetify-nix.legacyPackages.${pkgs.stdenv.hostPlatform.system};
in
{
  imports = [
    inputs.spicetify-nix.homeManagerModules.default
  ];

  home.username = "kamil";
  home.homeDirectory = "/home/kamil";

  programs.starship = {
    enable = true;
    enableBashIntegration = true;
  };

  # MangoWC config files (kept as plain files in the repo)
  xdg.configFile."mango/config.conf".source = ./mango/config.conf;
  xdg.configFile."mango/autostart.sh" = {
    source = ./mango/autostart.sh;
    executable = true;
  };

xdg.configFile."waybar/config.jsonc".source = ./waybar/config.jsonc;
xdg.configFile."waybar/style.css".source = ./waybar/style.css;
xdg.configFile."fastfetch/config.jsonc".source = ./fastfetch/config.jsonc;
xdg.configFile."alacritty/alacritty.toml".source = ./alacritty/alacritty.toml;
xdg.configFile."rofi/config.rasi".source = ./rofi/config.rasi;
xdg.configFile."rofi/powermenu.rasi".source = ./rofi/powermenu.rasi;
xdg.configFile."rofi/wallpaper.rasi".source = ./rofi/wallpaper.rasi;
xdg.configFile."nvim/init.lua".source = ./nvim/init.lua;
xdg.configFile."nvim/lazy-lock.json".source = ./nvim/lazy-lock.json;

xdg.configFile."rofi/scripts/powermenu.sh" = {
    source = ./rofi/scripts/powermenu.sh;
    executable= true;
    };
xdg.configFile."rofi/scripts/wallpicker.sh" = {
    source = ./rofi/scripts/wallpicker.sh;
    executable= true;
    };

  # Spicetify Configuration
  programs.spicetify = {
    enable = true;
    enabledExtensions = with spicePkgs.extensions; [
      fullAppDisplay
      shuffle
      hidePodcasts
    ];
  };

  home.stateVersion = "26.05";
  programs.home-manager.enable = true;
}
