#!/bin/sh

# Import environment into systemd and dbus (must come first)
dbus-update-activation-environment --systemd WAYLAND_DISPLAY XDG_CURRENT_DESKTOP=wlroots
systemctl --user import-environment WAYLAND_DISPLAY XDG_CURRENT_DESKTOP

# Polkit agent
(systemctl --user start hyprpolkitagent || hyprpolkitagent) >/dev/null 2>&1 &

# Wallpaper: restore last pick, fall back to a default
WALL="$(cat ~/.cache/current-wallpaper 2>/dev/null)"
[ -f "$WALL" ] || WALL="$(ls ~/Pictures/Wallpapers/* 2>/dev/null | head -n1)"
[ -n "$WALL" ] && swaybg -i "$WALL" -m fill >/dev/null 2>&1 &

# Desktop shell
mako >/dev/null 2>&1 &
waybar >/dev/null 2>&1 &
