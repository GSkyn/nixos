-- ============================================================================
-- Neovim Configuration (init.lua) - NixOS (No LSP / Lightweight Autocomplete)
-- Path: ~/.config/nvim/init.lua
-- ============================================================================

-- [Section 1] Set Leader key (MUST be defined before plugins load)
vim.g.mapleader = " "
vim.g.maplocalleader = " "

-- Shim for Neovim 0.11+ compatibility with legacy Treesitter calls
if vim.treesitter.language and not vim.treesitter.language.ft_to_lang then
	vim.treesitter.language.ft_to_lang = vim.treesitter.language.get_lang
end

-- [Section 2] Bootstrap lazy.nvim (Plugin Manager)
local lazypath = vim.fn.stdpath("data") .. "/lazy/lazy.nvim"
if not (vim.uv or vim.loop).fs_stat(lazypath) then
	vim.fn.system({
		"git",
		"clone",
		"--filter=blob:none",
		"https://github.com/folke/lazy.nvim.git",
		"--branch=stable",
		lazypath,
	})
end
vim.opt.rtp:prepend(lazypath)

-- [Section 3] Plugins Setup
require("lazy").setup({
	-- Theme: Tokyo Night (Opaque Background)
	{
		"folke/tokyonight.nvim",
		priority = 1000,
		config = function()
			require("tokyonight").setup({
				style = "night", -- Options: 'night', 'storm', 'day', 'moon'
				transparent = false, -- Ensures 100% opaque background
				styles = {
					sidebars = "dark", -- Solid background for sidebars (e.g. nvim-tree)
					floats = "dark", -- Solid background for floating windows
				},
			})
			vim.cmd.colorscheme("tokyonight-night")
		end,
	},

	-- Hex/RGB Color Code Highlighter
	{
		"NvChad/nvim-colorizer.lua",
		event = { "BufReadPre", "BufNewFile" },
		config = function()
			require("colorizer").setup({
				user_default_options = {
					RGB = true, -- #RGB hex codes
					RRGGBB = true, -- #RRGGBB hex codes
					-- names = true, -- "Name" codes like Blue or red
					RRGGBBAA = true, -- #RRGGBBAA hex codes
					rgb_fn = true, -- CSS rgb() and rgba() functions
					hsl_fn = true, -- CSS hsl() and hsla() functions
					css = true, -- Enable all CSS features
					mode = "background", -- Display mode: "background", "foreground", or "virtualtext"
				},
			})
		end,
	},

	-- File Path & Buffer Autocomplete (No LSP required)
	{
		"hrsh7th/nvim-cmp",
		event = "InsertEnter",
		dependencies = {
			"hrsh7th/cmp-path", -- Source for filesystem paths
			"hrsh7th/cmp-buffer", -- Source for text words in open buffer
			"L3MON4D3/LuaSnip", -- Required by nvim-cmp to prevent 'Invalid (empty) LHS' error
			"saadparwaiz1/cmp_luasnip",
		},
		config = function()
			local cmp = require("cmp")
			local luasnip = require("luasnip")

			cmp.setup({
				snippet = {
					expand = function(args)
						luasnip.lsp_expand(args.body)
					end,
				},
				mapping = cmp.mapping.preset.insert({
					["<C-b>"] = cmp.mapping.scroll_docs(-4),
					["<C-f>"] = cmp.mapping.scroll_docs(4),
					["<C-Space>"] = cmp.mapping.complete(),
					["<C-e>"] = cmp.mapping.abort(),
					["<CR>"] = cmp.mapping.confirm({ select = true }),
					["<Tab>"] = cmp.mapping(function(fallback)
						if cmp.visible() then
							cmp.select_next_item()
						elseif luasnip.expand_or_jumpable() then
							luasnip.expand_or_jump()
						else
							fallback()
						end
					end, { "i", "s" }),
					["<S-Tab>"] = cmp.mapping(function(fallback)
						if cmp.visible() then
							cmp.select_prev_item()
						elseif luasnip.jumpable(-1) then
							luasnip.jump(-1)
						else
							fallback()
						end
					end, { "i", "s" }),
				}),
				sources = cmp.config.sources({
					{ name = "path" }, -- Autocompletes folder/file paths
					{ name = "buffer" }, -- Autocompletes words in current buffer
				}),
			})
		end,
	},

	-- File Explorer Sidebar
	{
		"nvim-tree/nvim-tree.lua",
		dependencies = { "nvim-tree/nvim-web-devicons" },
		config = function()
			require("nvim-tree").setup()
			vim.keymap.set("n", "<leader>e", "<cmd>NvimTreeToggle<CR>", { desc = "Toggle Explorer" })
		end,
	},

	-- Fuzzy Finder
	{
		"nvim-telescope/telescope.nvim",
		branch = "master",
		dependencies = {
			"nvim-lua/plenary.nvim",
			{ "nvim-telescope/telescope-fzf-native.nvim", build = "make" },
		},
		config = function()
			local telescope = require("telescope")
			local builtin = require("telescope.builtin")

			telescope.setup()

			vim.keymap.set("n", "<leader>ff", function()
				builtin.find_files({ hidden = true })
			end, { desc = "Find files" })
			vim.keymap.set("n", "<leader>fg", builtin.live_grep, { desc = "Search text inside files" })
			vim.keymap.set("n", "<leader>fb", builtin.buffers, { desc = "Search open buffers" })
			vim.keymap.set("n", "<leader>fh", builtin.help_tags, { desc = "Search Neovim help" })
		end,
	},

	-- Treesitter: Advanced Syntax Highlighting
	{
		"nvim-treesitter/nvim-treesitter",
		build = ":TSUpdate",
		config = function()
			local status, configs = pcall(require, "nvim-treesitter.configs")
			if not status then
				return
			end

			configs.setup({
				ensure_installed = {
					"c",
					"lua",
					"vim",
					"vimdoc",
					"query",
					"markdown",
					"markdown_inline",
					"bash",
					"python",
					"javascript",
					"typescript",
					"json",
				},
				auto_install = true,
				highlight = { enable = true },
				indent = { enable = true },
			})
		end,
	},

	-- Auto-formatting on save
	{
		"stevearc/conform.nvim",
		event = { "BufWritePre" },
		cmd = { "ConformInfo" },
		opts = {
			formatters_by_ft = {
				lua = { "stylua" },
				python = { "isort", "black" },
				javascript = { "prettierd", "prettier" },
			},
			format_on_save = {
				timeout_ms = 500,
			},
		},
	},

	-- Git status signs in gutter
	{
		"lewis6991/gitsigns.nvim",
		config = function()
			require("gitsigns").setup()
		end,
	},

	-- Statusline
	{
		"nvim-lualine/lualine.nvim",
		dependencies = { "nvim-tree/nvim-web-devicons" },
		config = function()
			require("lualine").setup({
				options = {
					theme = "tokyonight",
				},
			})
		end,
	},
})

-- [Section 4] Indentation (4 Spaces)
vim.opt.tabstop = 4 -- Tab width = 4 spaces
vim.opt.softtabstop = 4 -- Edit width = 4 spaces
vim.opt.shiftwidth = 4 -- Auto-indent = 4 spaces
vim.opt.expandtab = true -- Convert tabs to spaces
vim.opt.smartindent = true -- Auto-indent new lines

-- [Section 5] Usability & Visuals
vim.opt.number = true -- Line numbers enabled in Neovim interface
vim.opt.relativenumber = true -- Relative line numbers
vim.opt.cursorline = true -- Highlight current line
vim.opt.termguicolors = true -- 24-bit RGB colors
vim.opt.clipboard = "unnamedplus" -- Sync with system clipboard
vim.opt.ignorecase = true -- Case-insensitive search
vim.opt.smartcase = true -- Smart-case search
vim.opt.signcolumn = "yes" -- Always show sign column to prevent text jumping

-- [Section 6] Core Shortcuts
vim.keymap.set("n", "<leader>w", "<cmd>w<CR>", { desc = "Save file" })
vim.keymap.set("n", "<leader>q", "<cmd>q<CR>", { desc = "Quit window" })
