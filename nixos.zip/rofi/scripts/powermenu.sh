#!/usr/bin/env bash

# --- CONFIGURATION ---
ROFI_THEME="$HOME/.config/rofi/powermenu.rasi"

# Nerd Font icon + label on one line (one row per option)
OPTION_SHUTDOWN="󰐥"
OPTION_REBOOT="󰜉"
OPTION_LOGOUT="󰍃"

# Format inputs for Rofi (one option per line)
MENU_INPUTS="$OPTION_SHUTDOWN\n$OPTION_REBOOT\n$OPTION_LOGOUT"

# Launch Rofi
CHOSEN=$(echo -e "$MENU_INPUTS" | rofi -dmenu \
    -i \
    -p "󰐥 Power" \
    -theme "$ROFI_THEME")

# Exit if nothing was chosen (Esc pressed)
[ -z "$CHOSEN" ] && exit 0

case "$CHOSEN" in
    "$OPTION_SHUTDOWN")
        systemctl poweroff
        ;;
    "$OPTION_REBOOT")
        systemctl reboot
        ;;
    "$OPTION_LOGOUT")
        mmsg dispatch quit
        ;;
esac
